package ac.id.amikom.simple_mvp;

public class WelcomeActivity {
}
