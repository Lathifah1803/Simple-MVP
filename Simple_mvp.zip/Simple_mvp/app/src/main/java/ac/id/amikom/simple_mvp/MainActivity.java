package ac.id.amikom.simple_mvp;

import ac.id.amikom.simple_mvp.presenter.LoginPresenter;
import ac.id.amikom.simple_mvp.view.LoginView;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements LoginView {

    EditText etUsername, etPassword;
    ProgressBar progressbar;
    Button btnlogin;

    LoginPresenter loginPresenter;
    private Bundle savedInstanceState;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        loginPresenter = new LoginPresenter((LoginView) this, new LoginInteractor());
    }

    void initViews() {
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        progressbar = findViewById(R.id.progressbar);
        btnlogin = findViewById(R.id.btnlogin);

    }


    public void loginMe(View view) {
        showProgressbar();

        loginPresenter.validateCredentials(etUsername.getText().toString().trim(), etPassword.getText().toString().trim());

    }

    @Override
    public void setUsernameError() {
        hideProgressbar();
        etUsername.setError("Username can't be empty!");

    }

    @Override
    public void setPasswordError() {

        hideProgressbar();
        etPassword.setError("password can't be empty!");
    }

    @Override
    public void onLoginSuccess(String username) {


        Intent intent = new Intent(this, WelcomeActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);

    }

    @Override
    public void onLoginError() {
        hideProgressbar();

        Toast.makeText(this, "username or password doesn't match", Toast.LENGTH_LONG).show();
    }

    @Override
    public void showProgressbar() {

        progressbar.setVisibility(View.VISIBLE);

    }

    @Override
    public void hideProgressbar() {

    }

}
