package ac.id.amikom.simple_mvp.view;

public interface LoginView {


    void setUsernameError();

    void setPasswordError();

    void onLoginSuccess(String username);

    void onLoginError();

    void showProgressbar();

    void hideProgressbar();
}
